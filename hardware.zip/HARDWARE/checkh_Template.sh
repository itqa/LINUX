#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions
###   TASK 4
### THIS TEMPLATE HAS 2 FUNCTIONS AS EXAMPLE. EACH FUNCTION DISPLAYS AN INFORMATION BASED ON THE LINE COMMAND
### DEFINED CLOSED TO THE END OF FUNCTION. EXAMPLE THE FIRST FUNCTION HAS THE COMMAND LINE lsscsi -s
### TASK 1
### REPLACE FOR EACH FUNCTION, THE FUNCTION NAME AND  ALL LINES TO REFLECT WHAT YOUR FUNCTION IS ABOUT AND WHAT COMMAND IS IN USE TO GET  ### THE INFORMATION. 
### TASK 2
### ALSO GOTTO TO SECTION MAIN AT THE END AND REPLACE/EDIT THE FUNCTION CALLS WITH THE NEW NAMES YOU ASSIGNED TO FUNCTIONS.
### TASK 3. YOU CAN BUILD AS MANY FUNCTIONS YOU NEED. NUMBER OF FUNCTIONS DEPENDS ON 


function SCSI_info
{
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">SCSI devices Information</h2>"
    echo "<pre>"
    echo "SCSI"
    sudo lsscsi -s
    echo "</pre>"
}

function SATA_info
{
    
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">SATA devices Information</h2>"
    echo "<pre>"
    echo "Sata"
    sudo hdparm /dev/sda1 -g
    echo "</pre>"
}

##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(SCSI_info)
      $(SATA_info)
     
  </body>
  </html>
_EOF_
       

