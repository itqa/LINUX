#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions

function system_info
{
    # Temporary function stub
    # echo "function system_info"

    echo "<h2 style="background-color:#FF0000">System release info</h2>"
    echo "<p>Function not yet implemented</p>"
}

function kernel_name
{
    # Temporary function stub
    # echo "kernel_info"
    echo "<h2 style="background-color:#00FF00">Kernel name</h2>"
    echo "<pre>"
    uname -s
    echo "<h2>Network node hostname</h2>" 
    uname -n
    echo "<h2>Kernel release </h2>" 
    uname -r
    echo "<h2>Kernel version</h2>"
    uname -v
    echo "<h2>Machine Hardware name</h2>"
    uname -m
    echo "<h2>Processor type</h2>"
    uname -p
    echo "<h2>Hardware platform</h2>"
    uname -i
    echo "<h2>Operating system</h2>"
    uname -o
    echo "</pre>"

}
function kernel_release
{
    # Temporary function stub
    # echo "kernel_Release"
    echo "<h2 style="background-color:#00FF00">Kernel Release</h2>"
    echo "<pre>"
    uname -r
    echo "</pre>"

}


function network_host_name
{
    # Temporary function stub
    # echo "kernel_info"
    echo "<h2 style="background-color:#00FF00">Network host name</h2>"
    echo "<pre>"
    uname -n
    echo "</pre>"

}
function process_current
{
    # Temporary function stub
    # echo "function show_uptime"
    echo "<h2 style="background-color:#00FF00">Processes currently in the System</h2>"
    echo "<pre>"
    ps
    echo "</pre>"
}

function files_home
{
    # Temporary function stub
    # echo "function show_uptime"
    echo "<h2 style="background-color:#00FF00">Files and dirs from home directory</h2>"
    echo "<pre>"
    cd ~/
    ls -l
    echo "</pre>"
}



function show_uptime
{
    # Temporary function stub
    # echo "function show_uptime"
    echo "<h2 style="background-color:#00FF00">System uptime</h2>"
    echo "<pre>"
    uptime
    echo "</pre>"
}



function drive_space
{
    # Temporary function stub
    # echo "function drive_space"
    echo "<h2 style="background-color:#00FF00">Filesystem space</h2>"
    echo "<pre>" 
    # df instead I use pydf taht provides coloring
    pydf -h
    echo "</pre>"
}


function home_space
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00"> Home directory space by user</h2>"
    echo "<pre>"
    echo "Bytes Directory"
    du -s /home/* | sort -nr
    echo "</pre>"
}

function hardware_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00"> Hardware Information</h2>"
    echo "<pre>"
    echo "Hardware"
    sudo lshw 
    echo "</pre>"
}

function CPU_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00"> CPU Information</h2>"
    echo "<pre>"
    echo "CPU"
    sudo lscpu
    echo "</pre>"
}

function block_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00"> Block Devices Information</h2>"
    echo "<pre>"
    echo "Block"
    sudo lsblk
    echo "</pre>"
}

function USB_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">USB Controllers Information</h2>"
    echo "<pre>"
    echo "USB"
    sudo lsusb -v
    echo "</pre>"
}

function PCI_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">PCI devices Information</h2>"
    echo "<pre>"
    echo "pci"
    sudo lspci -v
    echo "</pre>"
}

function SCSI_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">SCSI devices Information</h2>"
    echo "<pre>"
    echo "SCSI"
    sudo lsscsi -s
    echo "</pre>"
}

function SATA_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">SATA devices Information</h2>"
    echo "<pre>"
    echo "Sata"
    sudo hdparm /dev/sda1 -g
    echo "</pre>"
}

##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(kernel_name)
      $(kernel_release)
      $(network_host_name)
      $(process_current)
      $(files_home)
      $(system_info)
      $(show_uptime)
      $(drive_space)
      $(home_space)
      $(hardware_info)
      $(CPU_info)
      $(block_info)
      $(USB_info)
      $(PCI_info)
      $(SCSI_info)
      $(SATA_info)
     
  </body>
  </html>
_EOF_
       

