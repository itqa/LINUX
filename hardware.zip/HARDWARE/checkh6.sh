#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"



function drive_space
{
    # Temporary function stub
    # echo "function drive_space"
    echo "<h2 style="background-color:#00FF00">Filesystem space</h2>"
    echo "<pre>" 
    # df instead I use pydf taht provides coloring
    pydf -h
    echo "</pre>"
}


function home_space
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00"> Home directory space by user</h2>"
    echo "<pre>"
    echo "Bytes Directory"
    du -s /home/* | sort -nr
    echo "</pre>"
}



##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(drive_space)
      $(home_space)
      </body>
  </html>
_EOF_
       

