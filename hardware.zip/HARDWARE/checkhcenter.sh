#!/bin/bash
# system_page - A script to monitor various connections and produce
# system information in HTML file

##### Constants
TITLE="CONTROL CENTER for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions
# FUNCTION TO CHECK IF INTERNET IS CONNECTED

function net_center
{
echo -e "GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "<h2 style="background-color:#00FF00"><font size="5"> INTERNET IS CONNECTED </h2>"
	echo "Check utilizes the command:  GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1 ""
	echo "<h2 style="background-color:#00FF00"><font size="5"> HARDWARE INFORMATION CLICK ON </h2>"

set -e
	echo "<pre " "/pre>"
	echo "<a href="./checkh1.html" target="_blank">CHECK 1. SYSTEM RELEASE INFO!</a>"
	echo "<a href="./checkh2.html" target="_blank">CHECK 2. KERNEL INFO!</a>"
	echo "<a href="./checkh3.html" target="_blank">CHECK 3. CURRENT PROCESS!</a>"
	echo "<a href="./checkh4.html" target="_blank">CHECK 4. FILES AT HOME DIRECTORY!</a>"
	echo "<a href="./checkh5.html" target="_blank">CHECK 5. SHOW UPTIME!</a>"
	echo "<a href="./checkh6.html" target="_blank">CHECK 6. DRIVE AND HOME SPACE!</a>"
	echo "<a href="./checkh7.html" target="_blank">CHECK 7. HARDWARE INFORMATION!</a>"
	echo "<a href="./checkh8.html" target="_blank">CHECK 8. CPU INFORMATION!</a>"
	echo "<a href="./checkh9.html" target="_blank">CHECK 9. BLOCK INFORMATION!</a>"
	echo "<a href="./checkh10.html" target="_blank">CHECK 10. USB/PCI INFORMATION!</a>"
	echo "<a href="./checkh11.html" target="_blank">CHECK 11. SCSI/SATA INFORMATION!</a>"

## TASK 3
## COPY THE LINE BELOW AND UNCOMMENT IT. CHANGE THE PATH TO POINT TO APPROPRIATE ## FILE. MENU ITEM CHECK## TO BE REVISED AS IT FITS
## echo "<a href="./bin/myscripts/HARDWARE/checkh11.html" target="_blank">CHECK ##. ADD DESCRIPTION HERE</a>"


else
	echo "CHECK 1. INTERNET IF OFFLINE"
	echo "<h2 style="background-color:#FF0000"><font size="5"> INTERNET IS NOT CONNECTED</h2>"
fi
}


##### Main
cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(net_center)
  
  </body>
  </html>
_EOF_
      
