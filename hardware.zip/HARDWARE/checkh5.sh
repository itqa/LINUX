#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions


function show_uptime
{
    # Temporary function stub
    # echo "function show_uptime"
    echo "<h2 style="background-color:#00FF00">System uptime</h2>"
    echo "<pre>"
    uptime
    echo "</pre>"
}



##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(show_uptime)
      
  </body>
  </html>
_EOF_
       

