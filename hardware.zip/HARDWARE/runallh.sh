### SECTION 1.  
### ENSURE THAT ALL SCRIPTS ARE EXECUTABLE. EACH SCRIPT HERE REPRESENTS A NETWORK CHECK.

## checkh1.sh check if Internet exists. This check is repeated to every script below.
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh1.sh

## checkh2.sh KERNEL INFORMATION 
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh2.sh

## checkh3.sh CURRENT PROCESS
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh3.sh

## checkh4.sh FILES AT HOME DIRECTORY
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh4.sh

## checkh5.sh SHOW UPTIME
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh5.sh

## checkh6.sh DRIVE AND HOME SPACE
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh6.sh

## checkh7.sh HARWARE INFORMATION
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh7.sh

## checkh8.sh CPU INFORMATION
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh8.sh

## checkh9.sh BLOCK INFORMATION
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh9.sh

## checkh10.sh USB/PCI INFORMATION
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh10.sh

## checkh11.sh SCSI INFORMATION
sudo chmod 777 ./bin/myscripts/HARDWARE/checkh11.sh

                                 ##  TASK 1

## COPY THE 2 LINES BELOW. REMOVE THE COMMENT FROM THE SECOND LINE BELOW AND NAME THE SCRIPT checkh##.sh. WHERE ## ## APPROPRIATE NUMBER

## checkh##.sh SCSI INFORMATION
## sudo chmod 777 ./bin/myscripts/HARDWARE/checkh##.sh


### RUN SCRIPT TO CREATE CENTRAL WEB PAGE WITH LINKS TO ALL WEB PAGES
## checkhcenter displays all checks in a Central Page
sudo chmod 777 ./bin/myscripts/HARDWARE/checkhcenter.sh


### SECTION 2
### ENSURE THAT OUTPUT OF THE SCRIPT IS CREATED ON A WEB PAGE HTML FILE

# CENTER.HTML IS THE CENTRAL WEB PAGE WITH LINKS FOR ALL NETWORK CHECKS
bash ./bin/myscripts/HARDWARE/checkhcenter.sh>./bin/myscripts/HARDWARE/checkhcenter.html

# rest of commands below create one html page for each check.
bash ./bin/myscripts/HARDWARE/checkh1.sh>./bin/myscripts/HARDWARE/checkh1.html
bash ./bin/myscripts/HARDWARE/checkh2.sh>./bin/myscripts/HARDWARE/checkh2.html
bash ./bin/myscripts/HARDWARE/checkh3.sh>./bin/myscripts/HARDWARE/checkh3.html
bash ./bin/myscripts/HARDWARE/checkh4.sh>./bin/myscripts/HARDWARE/checkh4.html
bash ./bin/myscripts/HARDWARE/checkh5.sh>./bin/myscripts/HARDWARE/checkh5.html
bash ./bin/myscripts/HARDWARE/checkh6.sh>./bin/myscripts/HARDWARE/checkh6.html
bash ./bin/myscripts/HARDWARE/checkh7.sh>./bin/myscripts/HARDWARE/checkh7.html
bash ./bin/myscripts/HARDWARE/checkh8.sh>./bin/myscripts/HARDWARE/checkh8.html
bash ./bin/myscripts/HARDWARE/checkh9.sh>./bin/myscripts/HARDWARE/checkh9.html
bash ./bin/myscripts/HARDWARE/checkh10.sh>./bin/myscripts/HARDWARE/checkh10.html
bash ./bin/myscripts/HARDWARE/checkh11.sh>./bin/myscripts/HARDWARE/checkh11.html

				## TASK 2

## COPY LINE BELOW AND CREATE A NEW LINE. REMOVE COMMENTS ##. NAME NEW EXECUTABLE SCRIPT checkh## TO A NEW WEBPAGE HTML  FILE CHECKh##
## bash ./bin/myscripts/HARDWARE/checkh##.sh>./bin/myscripts/HARDWARE/checkh##.html


### SECTION 3

###  COMMAND BELOW OPENS THE CENTER.HTML. IF YOU WANT TO HAVE OPEN ALL TABS REMOVE THE # COMMENT FROM THE LINES.

# xdg-open  file:///home/angelos/bin/myscripts/HARDWARE/checkhcenter.html

xdg-open  ./bin/myscripts/HARDWARE/checkhcenter.html

##Exit immediately if a command exits with a non-zero exit status.

set -e
