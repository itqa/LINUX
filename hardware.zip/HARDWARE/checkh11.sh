#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions


function SCSI_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">SCSI devices Information</h2>"
    echo "<pre>"
    echo "SCSI"
    sudo lsscsi -s
    echo "</pre>"
}

function SATA_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">SATA devices Information</h2>"
    echo "<pre>"
    echo "Sata"
    sudo hdparm /dev/sda1 -g
    echo "</pre>"
}

##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(SCSI_info)
      $(SATA_info)
     
  </body>
  </html>
_EOF_
       

