#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions


function files_home
{
    # Temporary function stub
    # echo "function show_uptime"
    echo "<h2 style="background-color:#00FF00">Files and dirs from home directory</h2>"
    echo "<pre>"
    cd ~/
    ls -l
    echo "</pre>"
}

##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(files_home)
      
  </body>
  </html>
_EOF_
       

