#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions


function USB_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">USB Controllers Information</h2>"
    echo "<pre>"
    echo "USB"
    sudo lsusb -v
    echo "</pre>"
}

function PCI_info
{
    # Temporary function stub
    # echo "function home_space"
    echo "<h2 style="background-color:#00FF00">PCI devices Information</h2>"
    echo "<pre>"
    echo "pci"
    sudo lspci -v
    echo "</pre>"
}


##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(USB_info)
      $(PCI_info)
      
  </body>
  </html>
_EOF_
       

