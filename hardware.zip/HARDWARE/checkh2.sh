#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions

function system_info
{
    # Temporary function stub
    # echo "function system_info"

    echo "<h2 style="background-color:#FF0000">System release info</h2>"
    echo "<p>Function not yet implemented</p>"
}

function kernel_name
{
    # Temporary function stub
    # echo "kernel_info"
    echo "<h2 style="background-color:#00FF00">Kernel name</h2>"
    echo "<pre>"
    uname -s
    echo "<h2>Network node hostname</h2>" 
    uname -n
    echo "<h2>Kernel release </h2>" 
    uname -r
    echo "<h2>Kernel version</h2>"
    uname -v
    echo "<h2>Machine Hardware name</h2>"
    uname -m
    echo "<h2>Processor type</h2>"
    uname -p
    echo "<h2>Hardware platform</h2>"
    uname -i
    echo "<h2>Operating system</h2>"
    uname -o
    echo "</pre>"

}
function kernel_release
{
    # Temporary function stub
    # echo "kernel_Release"
    echo "<h2 style="background-color:#00FF00">Kernel Release</h2>"
    echo "<pre>"
    uname -r
    echo "</pre>"

}



##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(kernel_name)
      $(kernel_release)
      
  </body>
  </html>
_EOF_
       

