#!/bin/bash

# system_page - A script to produce an system information HTML file

##### Constants

TITLE="System Information for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions



function network_host_name
{
    # Temporary function stub
    # echo "kernel_info"
    echo "<h2 style="background-color:#00FF00">Network host name</h2>"
    echo "<pre>"
    uname -n
    echo "</pre>"

}
function process_current
{
    # Temporary function stub
    # echo "function show_uptime"
    echo "<h2 style="background-color:#00FF00">Processes currently in the System</h2>"
    echo "<pre>"
    ps
    echo "</pre>"
}



##### Main

cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(network_host_name)
      $(process_current)
      
  </body>
  </html>
_EOF_
       

