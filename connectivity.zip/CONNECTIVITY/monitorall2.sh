#!/bin/bash
# system_page - A script to monitor various connections and produce
# system information in HTML file

##### Constants
TITLE="Available Interfaces for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"

# FUNCTION TO DISPLAY AVAILABLE INTERFACES

## STEP 1. SAVE THE SCRIPT WITH THE NEW FILENAME. FOLLOW THE NUMERICAL SEQUENCE MONITORALL#.SH

##  STEP 2. RENAME THE FUNCTION TO REPRESENT A UNIQUE CHECK
function net_ifconfig
{
echo -e "GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "<h2 style="background-color:#00FF00"><font size="5"> CHECK 2. LIST OF AVAILABLE INTERFACE</h2>"


echo "<pre>"
echo "<b> <font size="5"> TYPES OF NETWORK INTERFACES </b>"

echo "The Linux kernel universally distinguishes between two types of software network interfaces:"

echo "<b> Physical Network Interfaces</b>"
echo "</pre>"

echo "eth0, eth8, radio0, wlan19, .. always represent an actual network hardware device such as a NIC, WNIC or some other kind of Modem. As soon as the device driver is loaded into the Kernel a corresponding physical network interface becomes present and available.

Any physical network interface is a named software representation by the operating system to the user to enable him to configure the hardware network device and also to integrate it into programs and scripts."

echo "<pre>"
echo "<b> Virtual Network Interfaces</b>"
echo "</pre>"

echo "lo, eth0:1, eth0.1, vlan2, br0, pppoe-dsl, gre0, sit0 tun0, imq0, teql0, .. are virtual network interfaces that do NOT represent an existent hardware device but are linked to one (otherwise they would be useless). Virtual network interfaces were invented to give the system administrator maximum flexibility when configuring a Linux-based operating system. A virtual network interface is generally associated with a physical network interface (eth6) or another virtual interface (eth6.9) or be stand alone such as the loopback interface lo."
echo "<pre>"
echo "<b> Maximum transmission unit (MTU)</b>"
echo "</pre>"

echo "
A maximum transmission unit (MTU) is the largest size packet or frame, specified in octets (eight-bit bytes), that can be sent in a packet- or frame-based network such as the Internet. The Internet's Transmission Control Protocol (TCP) uses the MTU to determine the maximum size of each packet in any transmission. Too large an MTU size may mean retransmissions if the packet encounters a router that can't handle that large a packet. Too small an MTU size means relatively more header overhead and more acknowledgements that have to be sent and handled. Most computer operating systems provide a default MTU value that is suitable for most users. In general, Internet users should follow the advice of their Internet service provider (ISP) about whether to change the default value and what to change it to.
"
echo "<pre>"
echo "<b> <font size="5"> qdisc</b>"
echo "</pre>"
echo "
 Simply put, a qdisc is a scheduler (Section 3.2). Every output interface needs a scheduler of some kind, and the default scheduler is a FIFO. Other qdiscs available under Linux will rearrange the packets entering the scheduler's queue in accordance with that scheduler's rules.
The qdisc is the major building block on which all of Linux traffic control is built, and is also called a queuing discipline."

echo "<pre>"
#  STEP 3. REPLACE THE NET COMMAND WITH YOUR CHOISE. SEND THE OUTPUT TO A TEXT FILE THAT NAME MATCHES THE FUNCTION
ip link show|sed '=;G'>net_ifconfig.txt
cat net_ifconfig.txt

echo "</pre>"

else
	echo "CHECK 1. INTERNET IF OFFLINE"
	echo "<h2 style="background-color:#FF0000"><font size="5"> INTERNET IS NOT CONNECTED</h2>"
fi
}


####STEP 4 REPLACE THE FUNCTION CALL $() BELOW WITH THE NEW NAME GIVEN TO FUNCTION.
cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
     $(net_ifconfig)
  </body>
  </html>
_EOF_
      
