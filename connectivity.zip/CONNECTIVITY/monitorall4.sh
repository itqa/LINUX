#!/bin/bash
# system_page - A script to monitor various connections and produce
# system information in HTML file

##### Constants
TITLE="Route table for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


# FUNCTION TO DISPLAY ROUTE TABLE
function net_route
{
echo -e "GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "<h2 style="background-color:#00FF00"><font size="5"> CHECK 4. DISPLAY ROUTE TABLE</h2>"

echo "<pre>"
echo "<b>Routing Table</b>"
echo "</pre>"

echo "Almost all computers and network devices connected to Internet use routing tables to compute the next hop for a packet. It is electronic table that is stored in a router or a networked computer. The routing table stores the routes (and in some cases, metrics associated with those routes) to particular network destinations. This information contains the topology of the network immediately around it. The construction of routing table is the primary goal of routing protocols and static routes.
Each Linux / UNIX / Windows or any computer that uses TCP/IP need to make routing decision. Routing table is used to control these decisions. "
echo "
Each router has three values Address, Mask and Gateway. Whenever an IP packet arrives at a router, its IP address is masked (using bit-wise AND) with a Router Mask and compared to a Router Address. If the the Masked IP address is same as Router Address it is sent to a corresponding gateway. Just keep in mind this is a simplification of the process, in reality it is a wee bit more complex.
In layman's terms each packet knows where he is headed (IP address) but doesn't know how to get there, so he asks each router for directions (masking IP address and comparing to router address). Of course routers probably don't know where exactly he should go, but they can give directions as to where they might find someone who can (gateway). In case they haven't got any clue where that place is, they just send you to a default gateway."



echo "<pre>"
netstat -r |sed '=;G'>net_route.txt
cat net_route.txt
echo "</pre>"
else
	echo "CHECK 1. INTERNET IF OFFLINE"
	echo "<h2 style="background-color:#FF0000"><font size="5"> INTERNET IS NOT CONNECTED</h2>"
fi
}


##### Main
cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(net_route)
  </body>
  </html>
_EOF_
      
