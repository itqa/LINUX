### ENSURE THAT ALL SCRIPTS ARE EXECUTABLE. EACH SCRIPT HERE REPRESENTS A NETWORK CHECK.

# STEP 5 ADD ANOTHER LINE TO CHANGE THE NEWLY CREATED SCRIPT MONITORALL# IN EXECUTABLE

## monitoall1 check if Internet exists. This check is repeated to every script below.
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorall1.sh

## monitoall2 displayes all available interfaces 
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorall2.sh

## monitoall3 displays all available interfaces with addresses
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorall3.sh

## monitoall4 displays Route Table
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorall4.sh

## monitoall5 displays Route Table
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorall5.sh

## monitoall6 displays connections
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorall6.sh

## monitoall7 displays tcp connections
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorall7.sh

## monitoall8 displays tcp connections
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorall8.sh

## monitoallc displays all checks in a Central Page
sudo chmod 777 ./bin/myscripts/CONNECTIVITY/monitorallc.sh

#ENSURE THAT ALL HTML PAGES CREATED.EACH HTML PAGE DISPLAYS INFO FOR EACH NETWORK CHECK. MAPPING IS BASED ON NUMBER.

##STEP 6. ADD A LINE BELOW TO DIRECT THE OUTPUT OF THE NEW EXECUTABLE SCRIPT MONITORALL# TO A NEW EXECUTABLE FILE CHECK#

# CENTER.HTML IS THE CENTRAL WEB PAGE WITH LINKS FOR ALL NETWORK CHECKS
bash ./bin/myscripts/CONNECTIVITY/monitorallc.sh>./bin/myscripts/CONNECTIVITY/center.html

# rest of commands below create one html page for each check.
bash ./bin/myscripts/CONNECTIVITY/monitorall1.sh>./bin/myscripts/CONNECTIVITY/check1.html
bash ./bin/myscripts/CONNECTIVITY/monitorall2.sh>./bin/myscripts/CONNECTIVITY/check2.html
bash ./bin/myscripts/CONNECTIVITY/monitorall3.sh>./bin/myscripts/CONNECTIVITY/check3.html
bash ./bin/myscripts/CONNECTIVITY/monitorall4.sh>./bin/myscripts/CONNECTIVITY/check4.html
bash ./bin/myscripts/CONNECTIVITY/monitorall5.sh>./bin/myscripts/CONNECTIVITY/check5.html
bash ./bin/myscripts/CONNECTIVITY/monitorall6.sh>./bin/myscripts/CONNECTIVITY/check6.html
bash ./bin/myscripts/CONNECTIVITY/monitorall7.sh>./bin/myscripts/CONNECTIVITY/check7.html
bash ./bin/myscripts/CONNECTIVITY/monitorall8.sh>./bin/myscripts/CONNECTIVITY/check8.html

###  COMMAND BELOW OPENS THE CENTER.HTML. IF YOU WANT TO HAVE OPEN ALL TABS REMOVE THE # COMMENT FROM THE LINES.

xdg-open  file:///home/angelos/bin/myscripts/CONNECTIVITY/center.html

##Exit immediately if a command exits with a non-zero exit status.

set -e
