#!/bin/bash
# system_page - A script to monitor various connections and produce
# system information in HTML file

##### Constants
TITLE="All connections for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"

##### Functions


# FUNCTION TO LIST ALL PORTS
function all_connect
{
echo -e "GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "<h2 style="background-color:#00FF00"><font size="5"> CHECK 6. LIST ALL CONNECTIONS</h2>"

echo "<pre>"
ss|sed '=;G'>all_connect.txt
cat all_connect.txt
echo "</pre>"
else
	echo "CHECK 1. INTERNET IF OFFLINE"
	echo "<h2 style="background-color:#FF0000"><font size="5"> INTERNET IS NOT CONNECTED</h2>"
fi
}



##### Main
cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(all_connect)
  </body>
  </html>
_EOF_
      
