#!/bin/bash
# system_page - A script to monitor various connections and produce
# system information in HTML file

##### Constants
TITLE="CONTROL CENTER for $HOSTNAME"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"


##### Functions
# FUNCTION TO CHECK IF INTERNET IS CONNECTED

function net_center
{
echo -e "GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1
if [ $? -eq 0 ]; then
	echo "<h2 style="background-color:#00FF00"><font size="5"> INTERNET IS CONNECTED </h2>"
	echo "Check utilizes the command:  GET http://google.com HTTP/1.0\n\n" | nc google.com 80 > /dev/null 2>&1 ""
	echo "<h2 style="background-color:#00FF00"><font size="5"> CONNECTIVITY CHECKS BELOW. CLICK ON </h2>"

set -e
	echo "<pre " "/pre>"
	echo "<a href="file:///home/angelos/bin/myscripts/CONNECTIVITY/check1.html" target="_blank">CHECK 1. INTERNET STATUS!</a>"
	echo "<a href="file:///home/angelos/bin/myscripts/CONNECTIVITY/check2.html" target="_blank">CHECK 2. AVAILABLE INTERFACES!</a>"
	echo "<a href="file:///home/angelos/bin/myscripts/CONNECTIVITY/check3.html" target="_blank">CHECK 3. IP ADDRESSES!</a>"
	echo "<a href="file:///home/angelos/bin/myscripts/CONNECTIVITY/check4.html" target="_blank">CHECK 4. ROUTE TABLE!</a>"
	echo "<a href="file:///home/angelos/bin/myscripts/CONNECTIVITY/check5.html" target="_blank">CHECK 5. ALL PORTS!</a>"
	echo "<a href="file:///home/angelos/bin/myscripts/CONNECTIVITY/check6.html" target="_blank">CHECK 6. ALL CONNECTIONS!</a>"
	echo "<a href="file:///home/angelos/bin/myscripts/CONNECTIVITY/check7.html" target="_blank">CHECK 7. ALL TCP CONNECTIONS!</a>"
	echo "<a href="file:///home/angelos/bin/myscripts/CONNECTIVITY/check8.html" target="_blank">CHECK 8. ALL UDP CONNECTIONS!</a>"

else
	echo "CHECK 1. INTERNET IF OFFLINE"
	echo "<h2 style="background-color:#FF0000"><font size="5"> INTERNET IS NOT CONNECTED</h2>"
fi
}


##### Main
cat <<- _EOF_
  <html>
  <head>
      <title style="background-color:#0000FF">$TITLE</title>
  </head>

  <body>
      <h1>$TITLE</h1>
      <p>$TIME_STAMP</p>
      $(net_center)
  
  </body>
  </html>
_EOF_
      
